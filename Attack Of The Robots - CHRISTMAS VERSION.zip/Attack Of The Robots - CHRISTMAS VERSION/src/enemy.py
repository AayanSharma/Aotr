import pygame
import math
import toolbox
import random
from explosion import Explosion
from powerup import PowerUp


class Enemy(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, player):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.image_picker = random.randint(0, 3)
        self.screen = screen
        self.x = x
        self.y = y
        self.player = player
        if self.image_picker == 0:
            self.image = pygame.image.load("../assets/Enemy_05.png")
            self.image_hurt = pygame.image.load("../assets/Enemy_05_Hurt.png")
        if self.image_picker == 1:
            self.image = pygame.image.load("../assets/Enemy_04.png")
            self.image_hurt = pygame.image.load("../assets/Enemy_04_Hurt.png")
        if self.image_picker == 2:
            self.image = pygame.image.load("../assets/Enemy_03.png")
            self.image_hurt = pygame.image.load("../assets/Enemy_03_Hurt.png")
        if self.image_picker == 3:
            self.image = pygame.image.load("../assets/Enemy_02.png")
            self.image_hurt = pygame.image.load("../assets/Enemy_02_Hurt.png")
        self.explosion_images = []
        self.explosion_images.append(pygame.image.load("../assets/MediumExplosion1.png"))
        self.explosion_images.append(pygame.image.load("../assets/MediumExplosion2.png"))
        self.explosion_images.append(pygame.image.load("../assets/MediumExplosion3.png"))
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.boom = pygame.mixer.Sound("../assets/sfx/explosion-small.wav")
        self.angle = 0
        self.speed = 1.6
        self.health = 20
        self.hurt_timer = 0
        self.damage = 1
        self.obstacle_anger = 0
        self.obstacle_anger_max = 100
        self.powerup_drop_chance = 20

    def update(self, projectiles, crates, explosions):

        self.angle = toolbox.angleBetweenPoints(self.x, self.y, self.player.x, self.player.y)

        angle_radians = math.radians(self.angle)
        self.x_move = math.cos(angle_radians) * self.speed
        self.y_move = -math.sin(angle_radians) * self.speed
        test_rect = self.rect
        new_x = self.x + self.x_move
        new_y = self.y + self.y_move

        test_rect.center = new_x, self.y
        for crate in crates:
            if test_rect.colliderect(crate.rect):
                new_x = self.x
                self.getAngry(crate)
        test_rect.center = self.x, new_y
        for crate in crates:
            if test_rect.colliderect(crate.rect):
                new_y = self.y
                self.getAngry(crate)
        for explosion in explosions:
            if explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    self.getHit(explosion.damage)
        self.x = new_x
        self.y = new_y
        self.rect.center = (self.x, self.y)

        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect):
                self.getHit(projectile.damage)
                projectile.explode()

        if self.hurt_timer <= 0:
            image_to_rotate = self.image
        else:
            image_to_rotate = self.image_hurt
            self.hurt_timer -= 1

        image_to_draw, image_rect = toolbox.getRotatedImage(image_to_rotate, self.rect, self.angle)

        self.screen.blit(image_to_draw, image_rect)

    def getHit(self, damage):
        if damage:
            self.hurt_timer = 10
        self.x -= self.x_move * 10
        self.y -= self.y_move * 10
        self.health -= damage
        if self.health <= 0:
            self.health = 99999
            self.player.getScore(50)

            Explosion(self.screen, self.x, self.y, self.explosion_images, 5, 0, False)
            self.boom.play()
            if random.randint(0, 100) >= self.powerup_drop_chance:
                PowerUp(self.screen, self.x, self.y)
            self.kill()

    def getAngry(self, crate):
        self.obstacle_anger += 1
        if self.obstacle_anger >= self.obstacle_anger_max:
            crate.hit_counter += .25
            self.obstacle_anger = 0






