import pygame
import random
import toolbox
class PowerUp(pygame.sprite.Sprite):
    def __init__(self, screen, x, y):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.pick_power = random.randint(0, 5)
        if self.pick_power == 0:
            self.image = pygame.image.load("../assets/powerupCrate.png")
            self.BGimage = pygame.image.load("../assets/powerupBackgroundBlue.png")
            self.power_type = "crateammo"
        elif self.pick_power == 1:
            self.image = pygame.image.load("../assets/powerupExplosiveCrate.png")
            self.BGimage = pygame.image.load("../assets/powerupBackgroundBlue.png")
            self.power_type = "explosivecrateammo"
        elif self.pick_power == 2:
            self.image = pygame.image.load("../assets/powerupSplitMidnight.png")
            self.BGimage = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = "splitshot"
        elif self.pick_power == 3:
            self.image = pygame.image.load("../assets/powerupHeart.png")
            self.BGimage = pygame.image.load("../assets/powerupBackgroundBlue.png")
            self.power_type = "health"
        elif self.pick_power == 4:
            self.image = pygame.image.load("../assets/powerupDrop.png")
            self.BGimage = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = "stream"
        elif self.pick_power == 5:
            self.image = pygame.image.load("../assets/SplashSmall1.png")
            self.BGimage = pygame.image.load("../assets/powerupBackgroundRed.png")
            self.power_type = "heavy"
        self.rect = self.image.get_rect()
        self.rect.center = self.x, self.y
        self.BGangle = 0
        self.spinnySpeed = 2
        self.despawntimer = 500
        self.sfx_powerup = pygame.mixer.Sound("../assets/sfx/powerup.wav")

    def update(self, player):
        self.despawntimer -= 1
        if self.despawntimer <= 0:
            self.kill()

        if self.rect.colliderect(player.rect):
            player.powerup(self.power_type)
            self.sfx_powerup.play()
            self.kill()

        BGimagetodraw, BGrect = toolbox.getRotatedImage(self.BGimage, self.rect, self.BGangle)

        self.BGangle += self.spinnySpeed
        if self.despawntimer > 120 or self.despawntimer % 10 > 5 :
            self.screen.blit(BGimagetodraw, BGrect)
            self.screen.blit(self.image, self.rect)
