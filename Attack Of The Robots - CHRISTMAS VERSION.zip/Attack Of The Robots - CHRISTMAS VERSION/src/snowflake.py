import pygame
import random
from projectile import WaterBalloon
class Snowflake(WaterBalloon):
    def __init__(self, screen, x, y, angle):
        WaterBalloon.__init__(self, screen, x, y, angle)

        self.image = pygame.image.load("../assets/Snowflake2.png")
        self.y = y
        self.x = x
        self.rect = self.image.get_rect()

    def update(self):
        self.rect.x = self.x
        self.rect.y += 1
        self.screen.blit(self.image, self.rect)

